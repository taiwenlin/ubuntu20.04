x=int(input("輸入x"))
if 18<=x<=65:
    y=x
else:
    y=150
print("y=%d"%(y))
