H=int(input("請輸入身高"))
if H<120:
    print("免費")
elif 120<=H<150:
    print("半價")
else:
    print("全票")
