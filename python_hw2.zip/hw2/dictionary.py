from operator import indexOf


d1={'Tom':0,'Amy':0,'Sam':0}
d1['Tom']=input("Tom:")
d1['Amy']=input("Amy:")
d1['Sam']=input("Sam:")
print(d1.get(input(),"none"))