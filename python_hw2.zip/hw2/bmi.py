def bmi(W,H):
    return W/H**2
print(bmi(52,1.75))