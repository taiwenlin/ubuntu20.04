def getmax(a,b,c):
    lst=[a,b,c]
    return max(lst)
print(getmax(1,4,3))
def get_sum(a,b,c,d):
    lst=[a,b,c,d]
    return sum(lst)
print(get_sum(1,2,3,4))
def get_average(a,b,c,d):
    lst=[a,b,c,d]
    return sum(lst)/len(lst)
print(get_average(1,2,3,4))
